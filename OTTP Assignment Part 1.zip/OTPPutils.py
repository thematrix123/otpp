class ServerContext():
    """
    Access to this object's instance variable is NOT thread safe. 
    Synchronization code needs to be implemented.
    """
    def __init__(self):
        self.tickerSet = set()
        
    def addTicker(self, ticker):
        self.tickerSet.add(ticker)
        
    def deleteTicker(self, ticker):
        self.tickerSet.remove(ticker)
        
    def getTickers(self):
        return set(self.tickerSet)

    def getTickersAsString(self):
        return ', '.join(self.tickerSet)

class RequestHandlerException(Exception):
    """
    Custom exception raised when error processing client requests
    """
    def __init__(self, message):
        self.message = message
    
    def __str__(self):
        return self.message
