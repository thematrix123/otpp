import socket
import argparse

def main():  
    def parse_cmd_line_args():
        '''
        Parse command line for default server:port, or use default values
        '''
        parser = argparse.ArgumentParser()
        parser.add_argument('--server', type=str, default='127.0.0.1:8000')
        args = parser.parse_args()
        host, port = args.server.split(':')
        return host.strip(), int(port)

#    HOST, PORT = parse_cmd_line_args()  #This throws exception when code is run as .ipynb
    HOST = "127.0.0.1"  # The server's hostname or IP address
    PORT = 8000  # The port used by the server
    
    try:        
        skt = None
        while True:
            queryString = input("Enter server request: ").strip()
            if queryString == 'q':
                break
                
            if skt is None: #Establish connection only if no connection
                skt = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                print(f'Connecting to {HOST}:{PORT}....')
                skt.connect((HOST, PORT))
              
            #WARNING: queryString should be parsed for a valid server query so that no
            #unncessary network traffic is generated due to an invalid query request
            skt.sendall(queryString.encode())
            data = skt.recv(1024).decode()
            print(f"Server Msg: {data!r}")
            
    except KeyboardInterrupt:
        print('Cntl-C detected...')
    except socket.error as e:
        print(f'Error creating socket: {e}')
    except socket.timeout as e:
        print(f'Connection to server timed out: {e}')
    except Exception as e:
        print(f'Unknown Exception: {e}')
    finally:
        if skt is not None:
            print('Closing connection....')
            skt.close()
    
    print('Exiting main()')
#
if __name__ == '__main__':
    main()
    