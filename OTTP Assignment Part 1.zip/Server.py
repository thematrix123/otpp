# -*- coding: utf-8 -*-
from argparse import ArgumentParser
import socket
#import multiprocessing
#import os
import OTPPrequestObjects
import OTPPutils

#Convenience functions
def loopTest(name):
    start, stop = 1, 1000000
    for num in range(start, stop):
        print("\tNumber %s of %s. Honk!" % (num, stop))
        time.sleep(1)


def parse_cmd_line_args():
    """
    Parse command line for port, sampling rate, ticker symbols, or use default values
    
    Returns
    -------
    port : int
        The port number to listen on.
    sampling : string
        Comma delimited string of default tickers to track
    sampling : int
        The intraday interval period for retreiving quotes from a datasource
    """
    
    parser = ArgumentParser()
    parser.add_argument('--port', type=int, default=8000)
    parser.add_argument('--sampling', type=int, default=5)
    parser.add_argument('--tickers', type=str, default='AAPL,MSFT,TOST')
    args = parser.parse_args()
    return int(args.port), args.tickers.strip(), int(args.sampling)


class RequestHandlerSingleton:
    """ 
    This classes uses a singleton pattern to ensure only one instance of this 
    handler exists during Server execution
    
    This singleton uses a Strategy Design pattern to handle all processing of
    client requests from adding/deleting tickers, getting quotes, and strategy 
    statistics by delegating to an appropriate object to complete the request. 
    
    When a client request is rec'd this singleton parses the request string 
    into a sinple 2-element tuple string  comprised of the client's request 
    command (data, add, delete, report) and request parameters (date, ticker).
    It then invokes a RequestFactory method to instantiate a concrete 
    implementation of an AbstractClientRequest representing the specific request
    command, and delegates to that request command to initialize itself by 
    passing it the request parameters since an AbstractClientRequest object 
    knows how to initialize itself anyway.
    
    Then the aAbstractClientRequest.execute(ServerContext) is invoked to carry
    out the  specific client request on the ServerContext and returns a results
    string representation to be sent back to the client.
    
    Singleton then enters a loop waiting for next request from this client
    connection.
    
    NOTE: This design implementation is extensible to handle new types of client
    requests in the future w/ almost no changes required to existing code 
    base.  For example to implement an entirely new client request, such as 
    to retrieve quotes between two user-specified dates instead of juse one, 
    we just need to create a new type of AbstractClientRequest class that 
    encapsulates the new request functinoarlity and adding few lines of code 
    to the RequestFactory class to instantiate that new class. 
    
    NOTE: Java supports dynamic class loading so introducing new classes like 
    above requires no change to code base. Python appears to support this too 
    (but need more time to study this).
    """
     
    _instance = None

    def __new__(cls, *args, **kwargs):
        """
        Override to create singleton pattern
        
        NOTE:  Access to _instance variable below is NOT thread-safe and
        needs to be synchronized.  Java provides the 'synchronized' keyword to
        synchronize threads when accessing shared variables.  From my current 
        and ongoing studying of Python it does not appear to have such a 
        similar/simple construct.  Instead Python has thread.lock() construct
        which seems to be equivalent but need more time to study so I have 
        omitted that for now in order to try to complete as much of the
        functionality of this project in the alloted time. 
        """
        if not cls._instance:
            cls._instance = super().__new__(cls, *args, **kwargs)
        return cls._instance
      
    def dispatch(this, socket_connection, server_ctx):
        """
        This method processes the client request on the given connection
        on the server's context
        
        Parameters
        ----------
        socket_connection : socket
            The socket connection associated with this request

        Returns
        -------
        string
             This handler's response from processing the request

        """        
        
        #Inner class defn
        def parse_request_helper(reqString):
            """
            Parse the request string into a 2-element tuple of the 1st word,
            and everythign else

            Parameters
            ----------
            reqString : TYPE
                The client request string

            Returns
            -------
            string
                The client query command ie.. add, delete, data, report
            string
                Everything else to the right of the client query command 

            """
            words = reqString.split()
            if len(words) > 1:
                return (words[0], " ".join(words[1:]))
            else:
                return (words[0], "")
        #End of inner class defn
        
        
        try:
            with socket_connection:
                while True:                    
                    #Rec'd client request
                    reqString = socket_connection.recv(1024).decode().strip()
                    if not reqString:
                        break
                    
                    reqCmd, reqParam = parse_request_helper(reqString)
                    
                    req = OTPPrequestObjects.RequestFactory.createRequest(reqCmd, reqParam)                    
                    resp = req.execute(server_ctx)                   
                    socket_connection.sendall(resp.encode())
                    
        except Exception as e: 
            raise   OTPPutils.RequestHandlerException(e)#let caller handle exceptions


def main():
    """
    This is the main() entry point for the server application
    """
    try:
        'Perform init'
        ctx = OTPPutils.ServerContext();  #This holds set of tickers
        HOST = "127.0.0.1"  
        PORT, SAMPLING, TICKERS = parse_cmd_line_args()

#        while True:        
        skt = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
        skt.bind((HOST, PORT))
       
        print(f"listening on {PORT}....") 
        skt.listen()
        conn, addr = skt.accept()     
        print(f"\tConnection from {addr}")

        """
        Dispatch client request to a separate request handler to process
        request.
        
        Ideally spawn new thread/process to handle request so that main() 
        thread does not block and can return/process new client requests.  For
        now dispatch using main() thread - consequently this server cannot 
        handle multiple client requests simultaneously at this time and WILL 
        block.
        
        To handle multiple requests use threading (need more time needed to 
        study Python Multihreading API), or do something like this:
        p = multiprocessing.Process(target=loopTest, args=("loop",))
        p.start()
        time.sleep(5)
        p.terminate()
        """
        RequestHandlerSingleton().dispatch(conn, ctx)
        
    except KeyboardInterrupt:  #This is not detecting my Cntrl-C keyboard entry
        print('Cntl-C detected...')
    except OTPPutils.RequestHandlerException as e:
        print(f'Error processing client request: {str(e)}')
    except Exception as e:
        print(f'Unknown Exception: {str(e)}')
    finally:
        print('Closing connection....')
        skt.close()

    print("Exiting main()")                
#                


if __name__ == '__main__':
    main()



