# -*- coding: utf-8 -*-
from abc import ABC, abstractmethod
from random import random
import OTPPutils


class AbstractClientRequest(ABC):
    """
    This class represents all types of client requests. New client requests in
    the future must implement all methods of this abstract base class in order
    to be invoked by the Server's request handling framework.
    """
   
    @abstractmethod
    def initialize(self, arg):
        """
        Initializes this request objects with the arguments specified

        Parameters
        ----------
        arg : string
            In a 'add/delete TICKER' request this string represents the ticker.
            In a 'data DATE-TIME' request this string represents the date-time
            In a 'report' request this string is None
            In a future type request this string is can be anything.  When this 
            this method is called the specific type of request knows how to
            initialize itself.            

        Returns
        -------
        None
        """    
    
    @abstractmethod
    def execute(self, ctx) -> str:
        """
        Executes the client request and returns a string reprsenting the 
        server's response for the client.  
        
        Inputs
        ------
        ctx : OTPPutils.ServerContext
        An object holding the server's cotext such as the lis of tickers being 
        tracked

        Returns
        -------
        str
            This could be the quotes data (when the client request is 'data',
            or server response message in the format:
                Status: 0  Msg: Success
                Status: 1  Msg: Server error
                Status: 2  Msg: Invalid ticker, ticker not found

        """
    
    def setStatusCode(self, number, message):
        """
        Set the status message upon execution of this request

        Parameters
        ----------
        number : integer
            0 = Success, 1 = Server Error, 2 = Some other error message
        message : string
            Server response message
            
        Returns
        -------
        None.
        """
        self.statusCd = number
        self.statusMsg = message
        
    def getStatusCode(self):
        return f"Status: {self.statusCd}     Msg: {self.statusMsg}"
  
    
class NOPRequest(AbstractClientRequest):
    """
    No operation performed by server.  This includes all unrecognized client
    requests.
    """
    def __init__(self, request_name):
        self.cmdString = request_name
    
    def initialize(self, arg):
        pass
        
    def execute(self, serverCtx ):
        self.setStatusCode(0, "Request not supported")
        return self.getStatusCode()


class AddTickerRequest(AbstractClientRequest):        
    """
    Add ticker request
    """
    def __init__(self, request_name):
        self.cmdString = request_name

    def initialize(self, arg):
        self.cmdParam = arg
        
    def execute(self, serverCtx):
        serverCtx.addTicker(self.cmdParam.upper())
        self.setStatusCode(0, f"{self.cmdParam} added to Server's Context")
        return self.getStatusCode()    
    
class DeleteTickerRequest(AbstractClientRequest):
    """
    Delete ticker request
    """
    def __init__(self, request_name):
        self.cmdString = request_name

    def initialize(self, arg):
        self.cmdParam = arg
        
    def execute(self, serverCtx):
        try:
            serverCtx.deleteTicker(self.cmdParam.upper())
            self.setStatusCode(0, f"{self.cmdParam} deleted from Server's Context")            
        except KeyError as e:
            self.setStatusCode(2, "Ticker not found")
        finally:
            return self.getStatusCode()    


class DataRequest(AbstractClientRequest):
    """
    Quote date reqeust.  This class connects to one of the two data sources
    to retrieve real time data
    """
    def __init__(self, request_name):
        self.cmdString = request_name

    def initialize(self, arg):
        pass
        
    def execute(self, serverCtx):
        tkSet = serverCtx.getTickers()
        quote_striing = ''
        for i, ticker in enumerate(tkSet):
            price = round(random() * 100, 2)
            quote_striing += f"{ticker}  {price}    "
        self.setStatusCode(0, quote_striing)
        return self.getStatusCode()    
            
        
        
    
    
class ListTickersRequest(AbstractClientRequest):
    """
    This is a new request.  It return list of tickers being tracked by server
    """
    def __init__(self, request_name):
        self.cmdString = request_name

    def initialize(self, arg):
        pass
        
    def execute(self, serverCtx):
        t = serverCtx.getTickersAsString()
        self.setStatusCode(0, "No tickers tracked" if len(t) == 0 else t  )
        return self.getStatusCode()    


class ReportRequest(AbstractClientRequest):
    """
    Generate report reqeust.  Server generates a CSV file with latest data,
    signal, PnL
    """
    def __init__(self, request_name):
        self.cmdString = request_name

    def initialize(self, arg):
        pass
        
    def execute(self, serverCtx):
        self.setStatusCode(1, "Not yet implemented")
        return self.getStatusCode()    
        
class RequestFactory:
    @staticmethod
    def createRequest(requestCommand, requestParameters) -> AbstractClientRequest:
        """
        Create concrete implememtaton of an AbstractClientRequest represented
        by the requestCommand argument
        
        Parameters
        ----------
        requestCommand: str
             A string representing the client's request ie. add/delete/data
             report
        requestParamerts: str
             The params associated with the request ie. ticker symbol in the 
             case request is 'add'/'delete', or date in the case request is 
             'data'

        Returns
        -------
        object : AbstractClientRequest
            A concrete implementation of an AbstractClientRequest

        """
      
        reqObj = None
      
        r = requestCommand.lower()
        p = requestParameters.lower()
        if   r == 'add':
            reqObj = AddTickerRequest(r)    
            reqObj.initialize(p)
        elif r == 'delete':
            reqObj = DeleteTickerRequest(r)  
            reqObj.initialize(p)
        elif r == 'data':
            reqObj = DataRequest(r)         
            reqObj.initialize(p)
        elif r == 'report':
            reqObj = ReportRequest(r)      
            reqObj.initialize(p)
        elif r == 'list':
            reqObj = ListTickersRequest(r)  #NEW REQUEST - get list of tickers tracked
            reqObj.initialize(p)
        else:
            reqObj = NOPRequest(r)      #No operation performed
            reqObj.initialize(p)
        
        return reqObj
            